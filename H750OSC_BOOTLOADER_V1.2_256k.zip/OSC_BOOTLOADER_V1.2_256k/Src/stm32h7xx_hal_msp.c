///* USER CODE BEGIN Header */
///**
//  ******************************************************************************
//  * File Name          : stm32h7xx_hal_msp.c
//  * Description        : This file provides code for the MSP Initialization 
//  *                      and de-Initialization codes.
//  ******************************************************************************
//  * @attention
//  *
//  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
//  * All rights reserved.</center></h2>
//  *
//  * This software component is licensed by ST under Ultimate Liberty license
//  * SLA0044, the "License"; You may not use this file except in compliance with
//  * the License. You may obtain a copy of the License at:
//  *                             www.st.com/SLA0044
//  *
//  ******************************************************************************
//  */
///* USER CODE END Header */

///* Includes ------------------------------------------------------------------*/
//#include "main.h"
///* USER CODE BEGIN Includes */

///* USER CODE END Includes */
//extern DMA_HandleTypeDef hdma_usart1_rx;

//extern DMA_HandleTypeDef hdma_usart1_tx;

///* Private typedef -----------------------------------------------------------*/
///* USER CODE BEGIN TD */

///* USER CODE END TD */

///* Private define ------------------------------------------------------------*/
///* USER CODE BEGIN Define */
// 
///* USER CODE END Define */

///* Private macro -------------------------------------------------------------*/
///* USER CODE BEGIN Macro */

///* USER CODE END Macro */

///* Private variables ---------------------------------------------------------*/
///* USER CODE BEGIN PV */

///* USER CODE END PV */

///* Private function prototypes -----------------------------------------------*/
///* USER CODE BEGIN PFP */

///* USER CODE END PFP */

///* External functions --------------------------------------------------------*/
///* USER CODE BEGIN ExternalFunctions */

///* USER CODE END ExternalFunctions */

///* USER CODE BEGIN 0 */

///* USER CODE END 0 */
///**
//  * Initializes the Global MSP.
//  */
//void HAL_MspInit(void)
//{
//  /* USER CODE BEGIN MspInit 0 */

//  /* USER CODE END MspInit 0 */

//  __HAL_RCC_SYSCFG_CLK_ENABLE();

//  /* System interrupt init*/

//  /* USER CODE BEGIN MspInit 1 */

//  /* USER CODE END MspInit 1 */
//}

///**
//* @brief UART MSP Initialization
//* This function configures the hardware resources used in this example
//* @param huart: UART handle pointer
//* @retval None
//*/
//void HAL_UART_MspInit(UART_HandleTypeDef* huart)
//{
//  GPIO_InitTypeDef GPIO_InitStruct = {0};
//  if(huart->Instance==USART1)
//  {
//  /* USER CODE BEGIN USART1_MspInit 0 */

//  /* USER CODE END USART1_MspInit 0 */
//    /* Peripheral clock enable */
//    __HAL_RCC_USART1_CLK_ENABLE();
//  
//    __HAL_RCC_GPIOA_CLK_ENABLE();
//    /**USART1 GPIO Configuration    
//    PA9     ------> USART1_TX
//    PA10     ------> USART1_RX 
//    */
//    GPIO_InitStruct.Pin = GPIO_PIN_9|GPIO_PIN_10;
//    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
//    GPIO_InitStruct.Pull = GPIO_NOPULL;
//    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
//    GPIO_InitStruct.Alternate = GPIO_AF7_USART1;
//    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

//    /* USART1 DMA Init */
//    /* USART1_RX Init */
//    hdma_usart1_rx.Instance = DMA1_Stream0;
//    hdma_usart1_rx.Init.Request = DMA_REQUEST_USART1_RX;
//    hdma_usart1_rx.Init.Direction = DMA_PERIPH_TO_MEMORY;
//    hdma_usart1_rx.Init.PeriphInc = DMA_PINC_DISABLE;
//    hdma_usart1_rx.Init.MemInc = DMA_MINC_ENABLE;
//    hdma_usart1_rx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
//    hdma_usart1_rx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
//    hdma_usart1_rx.Init.Mode = DMA_CIRCULAR;
//    hdma_usart1_rx.Init.Priority = DMA_PRIORITY_LOW;
//    hdma_usart1_rx.Init.FIFOMode = DMA_FIFOMODE_DISABLE;
//    if (HAL_DMA_Init(&hdma_usart1_rx) != HAL_OK)
//    {
//      Error_Handler();
//    }

//    __HAL_LINKDMA(huart,hdmarx,hdma_usart1_rx);

//    /* USART1_TX Init */
//    hdma_usart1_tx.Instance = DMA1_Stream1;
//    hdma_usart1_tx.Init.Request = DMA_REQUEST_USART1_TX;
//    hdma_usart1_tx.Init.Direction = DMA_MEMORY_TO_PERIPH;
//    hdma_usart1_tx.Init.PeriphInc = DMA_PINC_DISABLE;
//    hdma_usart1_tx.Init.MemInc = DMA_MINC_ENABLE;
//    hdma_usart1_tx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
//    hdma_usart1_tx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
//    hdma_usart1_tx.Init.Mode = DMA_NORMAL;
//    hdma_usart1_tx.Init.Priority = DMA_PRIORITY_LOW;
//    hdma_usart1_tx.Init.FIFOMode = DMA_FIFOMODE_DISABLE;
//    if (HAL_DMA_Init(&hdma_usart1_tx) != HAL_OK)
//    {
//      Error_Handler();
//    }

//    __HAL_LINKDMA(huart,hdmatx,hdma_usart1_tx);

//  /* USER CODE BEGIN USART1_MspInit 1 */

//  /* USER CODE END USART1_MspInit 1 */
//  }

//}

///**
//* @brief UART MSP De-Initialization
//* This function freeze the hardware resources used in this example
//* @param huart: UART handle pointer
//* @retval None
//*/
//void HAL_UART_MspDeInit(UART_HandleTypeDef* huart)
//{
//  if(huart->Instance==USART1)
//  {
//  /* USER CODE BEGIN USART1_MspDeInit 0 */

//  /* USER CODE END USART1_MspDeInit 0 */
//    /* Peripheral clock disable */
//    __HAL_RCC_USART1_CLK_DISABLE();
//  
//    /**USART1 GPIO Configuration    
//    PA9     ------> USART1_TX
//    PA10     ------> USART1_RX 
//    */
//    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_9|GPIO_PIN_10);

//    /* USART1 DMA DeInit */
//    HAL_DMA_DeInit(huart->hdmarx);
//    HAL_DMA_DeInit(huart->hdmatx);
//  /* USER CODE BEGIN USART1_MspDeInit 1 */

//  /* USER CODE END USART1_MspDeInit 1 */
//  }

//}

///* USER CODE BEGIN 1 */

///* USER CODE END 1 */

///************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
